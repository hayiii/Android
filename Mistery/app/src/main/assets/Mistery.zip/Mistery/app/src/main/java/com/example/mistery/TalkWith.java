package com.example.mistery;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.mistery.msg.Msg;
import com.example.mistery.msg.MsgAdapter;

import java.util.ArrayList;
import java.util.List;

public class TalkWith extends AppCompatActivity {
    private List<Msg> msgList = new ArrayList<Msg>();
    private TextView posName;
    private ImageView msgToSend;

    private ImageView backBt;
    private ImageView moreBt;

    private RecyclerView msgRecyclerView;
    private MsgAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_talkwith);

        posName = findViewById(R.id.name);
        backBt = findViewById(R.id.back_bt);
        moreBt = findViewById(R.id.for_more_bt);
        msgRecyclerView = findViewById(R.id.msg_layout);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        msgRecyclerView.setLayoutManager(layoutManager);
        adapter = new MsgAdapter(msgList);
        msgRecyclerView.setAdapter(adapter);
    }


}
