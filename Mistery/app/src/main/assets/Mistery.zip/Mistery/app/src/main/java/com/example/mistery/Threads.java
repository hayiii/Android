package com.example.mistery;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Threads extends AppCompatActivity {
    private String[] corpseList;
    private String[] threadList;

    private LinearLayout corpseLayout;
    private LinearLayout threadLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_threads);

        corpseList = getResources().getStringArray(R.array.corpse);
        threadList = getResources().getStringArray(R.array.threads);

        corpseLayout = findViewById(R.id.corpse);
        threadLayout = findViewById(R.id.thread);

        initView();
    }

    private void initView(){
        for (int i = 0;i<corpseList.length;i++){
            View view = LayoutInflater.from(this).inflate(R.layout.thread_item,corpseLayout,false);
            TextView textView = view.findViewById(R.id.thread_tv);
            textView.setText(corpseList[i]);
            corpseLayout.addView(view);
        }

        for (int i = 0;i<threadList.length;i++){
            View view = LayoutInflater.from(this).inflate(R.layout.thread_item,threadLayout,false);
            TextView textView = view.findViewById(R.id.thread_tv);
            textView.setText(threadList[i]);
            threadLayout.addView(view);
        }

    }

    public static void addThread(String s,int m){
        Threads threads = new Threads();
        switch (m){
            case 0:
                View view = LayoutInflater.from(threads).inflate(R.layout.thread_item,threads.corpseLayout,false);
                TextView textView = view.findViewById(R.id.thread_tv);
                textView.setText(s);
                threads.corpseLayout.addView(view);
                break;
            case 1:
                View view1 = LayoutInflater.from(threads).inflate(R.layout.thread_item,threads.threadLayout,false);
                TextView textView1 = view1.findViewById(R.id.thread_tv);
                textView1.setText(s);
                threads.threadLayout.addView(view1);
                break;
                default:
                    break;
        }
    }
}
