package com.example.mistery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.mistery.util.TextViewUtils;

import static java.lang.Thread.sleep;

public class StartGame extends AppCompatActivity {
    private TextView storyTv;
    private TextView taskTv;
    private LinearLayout storyLayout;

    private TextViewUtils textViewUtils;
    private TextViewUtils tvUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_start);

        storyTv = findViewById(R.id.story_tv);
        textViewUtils = new TextViewUtils(storyTv,getResources().getString(R.string.story),100);

        try {
            sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        taskTv = findViewById(R.id.task_tv);
        tvUtil = new TextViewUtils(taskTv,getResources().getString(R.string.task),100);

        storyLayout = findViewById(R.id.story_layout);
        storyLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StartGame.this,MainView.class);
                startActivity(intent);
            }
        });
    }
}
