package com.example.mistery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;

public class Splash extends AppCompatActivity {
   // private TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);   //隐藏状态栏
        getSupportActionBar().hide();//隐藏标题栏
        setContentView(R.layout.activity_splash);
        //text = findViewById(R.id.text);
        //Typeface typeface = Typeface.createFromAsset(getAssets(),"fonts/DroidSansFallback.ttf");
        //text.setTypeface(typeface);
        new Thread(){
            @Override
            public void run(){
                try {
                    sleep(4000);//休眠4秒
                    Intent it = new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(it);
                    finish();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }
}
