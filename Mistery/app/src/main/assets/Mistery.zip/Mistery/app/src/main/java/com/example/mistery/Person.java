package com.example.mistery;

public class Person {
    private String name;
    private String relative;
    private String more;

    public Person(String name,String relative){
        this.name = name;
        this.relative = relative;
    }

    public void setMore(String more){
        this.more = more;
    }

    public String getName(){
        return name;
    }

    public String getRelative(){
        return relative;
    }

    public String getMore(){
        return more;
    }
}
