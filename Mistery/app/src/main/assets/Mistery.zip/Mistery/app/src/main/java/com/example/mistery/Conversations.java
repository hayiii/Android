package com.example.mistery;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Conversations extends AppCompatActivity {


    private LinearLayout converLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversations);

        converLayout = findViewById(R.id.conversation_list);

    }

    private void initView() {
        View view = LayoutInflater.from(this).inflate(R.layout.conver_item, converLayout, false);
        ImageView head = view.findViewById(R.id.con_iv);
        TextView name = view.findViewById(R.id.con_tv);
        TextView latest = view.findViewById(R.id.latest_talk);
        head.setImageDrawable(getResources().getDrawable(R.drawable.man1));
        name.setText("李惠");
        latest.setText("nice to meet u.");
        converLayout.addView(view);
    }
}
