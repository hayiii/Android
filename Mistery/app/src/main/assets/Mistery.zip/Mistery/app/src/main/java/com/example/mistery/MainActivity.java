package com.example.mistery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.mistery.util.FontsUtil;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button startGame;
    private Button loadGame;
    private Button aboutGame;

    public static List<Person> personList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FontsUtil.setDefaultFont(this,"SERIF","fonts/dq.otf");
        setContentView(R.layout.activity_main);

        startGame = findViewById(R.id.start_game);
        loadGame = findViewById(R.id.load_game);
        aboutGame = findViewById(R.id.about_game);

        startGame.setOnClickListener(this);
        loadGame.setOnClickListener(this);
        aboutGame.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.start_game:
                Intent intent = new Intent(MainActivity.this,StartGame.class);
                startActivity(intent);
            case R.id.load_game:
            case R.id.about_game:
        }
    }
}
