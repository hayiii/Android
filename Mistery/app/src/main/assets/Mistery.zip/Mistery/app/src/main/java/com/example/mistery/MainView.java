package com.example.mistery;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;

import com.example.mistery.myview.BottomBar;

public class MainView extends AppCompatActivity {
    //private BottomBar bottomBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_view);

        /*bottomBar = findViewById(R.id.bottom_bar);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            bottomBar.setContainer(R.id.main_view)
                    .setTitleBeforeAndAfterColor("#999999","#ff5d5e")
                    .addItem(Conversations.class,"聊天",R.drawable.chat_before,R.drawable.chat_after)
                    .addItem(Threads.class,"线索",R.drawable.xs_before,R.drawable.xs_after).build();
        }*/
    }
}
